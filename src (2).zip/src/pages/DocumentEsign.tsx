import React, { useState } from 'react';
import Layout from '../components/Layout';
import { apiPost } from '../utils/api';

const DocumentEsign: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setError(null);
      setSuccess(null);
    }
  };

  const handleSubmit = async () => {
    if (!selectedFile) {
      setError('Please select a file first');
      return;
    }

    setLoading(true);
    setError(null);
    setSuccess(null);

    try {
      const formData = new FormData();
      formData.append('document', selectedFile);

      const response = await apiPost('/api/document-esign', formData, 'multipart/form-data');
      
      if (response.ok) {
        setSuccess('Document uploaded successfully for e-signature!');
        setSelectedFile(null);
        // Reset file input
        const fileInput = document.getElementById('file-input') as HTMLInputElement;
        if (fileInput) fileInput.value = '';
      } else {
        const errorData = await response.json();
        setError(errorData.message || 'Failed to upload document');
      }
    } catch (err) {
      setError('An error occurred while uploading the document');
      console.error('Upload error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="mainInternalPages">
        {/* Dashboard Header */}
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          padding: '12px 0'
        }}>
          <div className="commonTitle">
            <div className="icon">
              <i className="ri-file-signature-fill"></i>
            </div>
            <h1>Document E-Signature</h1>
          </div>
          <button
            onClick={() => window.history.back()}
            style={{
              background: 'linear-gradient(135deg, #30ea03 0%, #28c402 100%)',
              border: 'none',
              color: 'white',
              fontSize: 14,
              fontWeight: 600,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              padding: '8px 16px',
              borderRadius: '8px',
              transition: 'all 0.3s ease',
              minWidth: '100px',
              justifyContent: 'center'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            <i className="ri-arrow-left-line" style={{ fontSize: 18, marginRight: 6 }} />
            Back
          </button>
        </div>

        {/* Information Bar */}
        <div className="filters CMDetails">
          <div className="row">
            <div className="col-sm-12">
              <ul style={{ display: 'flex', alignItems: 'center', padding: '6px 15px 8px' }}>
                <li><strong>Document Type: </strong> E-Signature Request</li>
                <li> | </li>
                <li><strong>Status: </strong> Ready for Upload</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Main Content Card */}
        <div className="row">
          <div className="col-sm-12">
            <div style={{
              backgroundColor: '#f8f9fa',
              borderRadius: '8px',
              padding: '30px',
              marginTop: '20px',
              border: '1px solid #e9ecef'
            }}>
              <div style={{ marginBottom: '25px' }}>
                <h4 style={{ 
                  color: '#495057', 
                  marginBottom: '15px',
                  fontSize: '18px',
                  fontWeight: '600'
                }}>
                  Upload Document for E-Signature
                </h4>
                <p style={{ 
                  color: '#6c757d', 
                  fontSize: '14px',
                  margin: 0
                }}>
                  Select a document to be signed electronically. Supported formats: PDF, DOC, DOCX, JPG, PNG, GIF
                </p>
              </div>

              {/* File Upload Section */}
              <div style={{ marginBottom: '25px' }}>
                <div style={{ marginBottom: '15px' }}>
                  <label style={{
                    display: 'block',
                    marginBottom: '8px',
                    fontWeight: '600',
                    color: '#495057',
                    fontSize: '14px'
                  }}>
                    Browse Document File
                  </label>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
                    <input
                      id="file-input"
                      type="file"
                      onChange={handleFileSelect}
                      accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.gif"
                      style={{ display: 'none' }}
                    />
                    <button
                      onClick={() => document.getElementById('file-input')?.click()}
                      style={{
                        background: '#fff',
                        border: '1px solid #dee2e6',
                        color: '#495057',
                        padding: '8px 16px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500',
                        transition: 'all 0.2s ease'
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = '#30ea03';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#dee2e6';
                      }}
                    >
                      Choose File
                    </button>
                    <span style={{
                      color: '#6c757d',
                      fontSize: '14px'
                    }}>
                      {selectedFile ? selectedFile.name : 'No file chosen'}
                    </span>
                  </div>
                </div>

                {/* Submit Button */}
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button
                    onClick={handleSubmit}
                    disabled={!selectedFile || loading}
                    style={{
                      background: selectedFile && !loading ? '#30ea03' : '#6c757d',
                      color: 'white',
                      border: 'none',
                      padding: '10px 24px',
                      borderRadius: '6px',
                      fontSize: '14px',
                      fontWeight: '600',
                      cursor: selectedFile && !loading ? 'pointer' : 'not-allowed',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'all 0.2s ease',
                      opacity: selectedFile && !loading ? 1 : 0.6
                    }}
                    onMouseEnter={(e) => {
                      if (selectedFile && !loading) {
                        e.currentTarget.style.transform = 'translateY(-1px)';
                        e.currentTarget.style.boxShadow = '0 4px 8px rgba(48, 234, 3, 0.3)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (selectedFile && !loading) {
                        e.currentTarget.style.transform = 'translateY(0)';
                        e.currentTarget.style.boxShadow = 'none';
                      }
                    }}
                  >
                    {loading ? (
                      <>
                        <i className="ri-loader-4-line spinning" style={{ fontSize: '16px' }}></i>
                        Processing...
                      </>
                    ) : (
                      <>
                        <i className="ri-send-plane-2-line" style={{ fontSize: '16px' }}></i>
                        Submit for E-Signature
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Instructions */}
              <div style={{
                backgroundColor: '#e9ecef',
                padding: '15px',
                borderRadius: '6px',
                borderLeft: '4px solid #30ea03'
              }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                  <i className="ri-information-line" style={{ 
                    color: '#30ea03', 
                    fontSize: '18px',
                    marginTop: '2px'
                  }}></i>
                  <div>
                    <h6 style={{ 
                      margin: '0 0 8px 0', 
                      color: '#495057',
                      fontSize: '14px',
                      fontWeight: '600'
                    }}>
                      What happens next?
                    </h6>
                    <ul style={{ 
                      margin: 0, 
                      paddingLeft: '20px',
                      color: '#6c757d',
                      fontSize: '13px',
                      lineHeight: '1.5'
                    }}>
                      <li>Your document will be uploaded securely</li>
                      <li>An e-signature request will be sent to the designated signers</li>
                      <li>You'll receive notifications on the signature progress</li>
                      <li>Once completed, you can download the signed document</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <div style={{
                  backgroundColor: '#f8d7da',
                  color: '#721c24',
                  padding: '12px',
                  borderRadius: '6px',
                  marginTop: '20px',
                  border: '1px solid #f5c6cb',
                  fontSize: '14px'
                }}>
                  <i className="ri-error-warning-line" style={{ marginRight: '8px' }}></i>
                  {error}
                </div>
              )}

              {/* Success Message */}
              {success && (
                <div style={{
                  backgroundColor: '#d4edda',
                  color: '#155724',
                  padding: '12px',
                  borderRadius: '6px',
                  marginTop: '20px',
                  border: '1px solid #c3e6cb',
                  fontSize: '14px'
                }}>
                  <i className="ri-check-line" style={{ marginRight: '8px' }}></i>
                  {success}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Enhanced styles */}
        <style>{`
          .spinning {
            animation: spin 1s linear infinite;
          }
          
          @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          
          .mainInternalPages {
            padding: 20px;
            background-color: #fff;
          }
          
          .commonTitle {
            display: flex;
            align-items: center;
            gap: 12px;
          }
          
          .commonTitle .icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #30ea03 0%, #28c402 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
          }
          
          .commonTitle h1 {
            margin: 0;
            color: #2c3e50;
            font-size: 24px;
            font-weight: 600;
          }
          
          .filters.CMDetails {
            background: #30ea03;
            border-radius: 6px;
            margin-bottom: 20px;
          }
          
          .filters.CMDetails ul {
            list-style: none;
            margin: 0;
            padding: 0;
          }
          
          .filters.CMDetails li {
            color: #000;
            font-size: 14px;
            font-weight: 500;
          }
          
          .filters.CMDetails strong {
            color: #000;
            font-weight: 600;
          }
        `}</style>
      </div>
    </Layout>
  );
};

export default DocumentEsign;
